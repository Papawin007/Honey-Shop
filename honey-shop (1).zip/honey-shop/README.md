# ร้านน้ำผึ้ง – Landing Page + Google Sheet + Pick/Pack/Label

## โครงสร้าง
- index.html – landing page + ฟอร์มสั่งซื้อ
- pack.html – รายการหยิบ, ใบแพ็ค, ใบปะหน้าพัสดุ (กดพิมพ์ได้)
- images/ – โฟลเดอร์รูปแยกต่างหาก
- config.js – ใส่ URL ของ Google Sheet / Apps Script
- apps-script.gs – โค้ดรับออเดอร์ลง Sheet
- products.sample.csv – ตัวอย่างข้อมูลสินค้า (2 SKUs)

## ขั้นตอน
1. สร้าง Google Sheet 2 แท็บ: `products` (วางข้อมูลจาก products.sample.csv) และ `orders` (แถวแรก: order_id,timestamp,customer,phone,address,sku,product,qty,price,total,status)
2. File > Share > Publish to web > แท็บ products > CSV > คัดลอก URL ใส่ `PRODUCTS_CSV_URL` ใน config.js
3. Extensions > Apps Script > วาง apps-script.gs > Deploy > Web app (Execute as: Me, Access: Anyone) > คัดลอก URL ใส่ `ORDERS_API_URL`
4. แก้ชื่อร้าน/ที่อยู่ผู้ส่งใน config.js
5. สร้าง repo ใน GitHub แล้วอัปโหลดทุกไฟล์ (รวมโฟลเดอร์ images)
6. vercel.com > Add New Project > Import repo > Deploy (Framework: Other)
7. ใช้งาน: ลูกค้าเปิด `/` ส่วนร้านเปิด `/pack` เพื่อพิมพ์ใบหยิบ/ใบปะหน้า
8. เมื่อแพ็คเสร็จ เปลี่ยนคอลัมน์ status ใน Sheet จาก new เป็น packed
