// Google Sheet ต้องมีแท็บ "products" และ "orders"
// orders header: order_id,timestamp,customer,phone,address,sku,product,qty,price,total,status
function doPost(e) {
  var d = JSON.parse(e.postData.contents);
  var sh = SpreadsheetApp.getActive().getSheetByName("orders");
  var id = "ORD" + Utilities.formatDate(new Date(), "Asia/Bangkok", "yyMMddHHmmss");
  d.items.forEach(function (i) {
    sh.appendRow([id, new Date(), d.customer, "'" + d.phone, d.address,
      i.sku, i.name, i.qty, i.price, i.qty * i.price, "new"]);
  });
  return ContentService.createTextOutput(JSON.stringify({ ok: true, id: id }))
    .setMimeType(ContentService.MimeType.JSON);
}
function doGet() {
  var v = SpreadsheetApp.getActive().getSheetByName("orders").getDataRange().getValues();
  var h = v.shift();
  var rows = v.map(function (r) { var o = {}; h.forEach(function (k, i) { o[k] = r[i]; }); return o; });
  return ContentService.createTextOutput(JSON.stringify(rows)).setMimeType(ContentService.MimeType.JSON);
}
