function parseCSV(t){const r=[];let c=[],f="",q=false;for(let i=0;i<t.length;i++){const ch=t[i];
if(q){if(ch=='"'&&t[i+1]=='"'){f+='"';i++}else if(ch=='"')q=false;else f+=ch}
else if(ch=='"')q=true;else if(ch==","){c.push(f);f=""}
else if(ch=="\n"||ch=="\r"){if(ch=="\r"&&t[i+1]=="\n")i++;c.push(f);r.push(c);c=[];f=""}else f+=ch}
if(f||c.length){c.push(f);r.push(c)}const h=r.shift().map(x=>x.trim());
return r.filter(x=>x.length>1).map(x=>Object.fromEntries(h.map((k,i)=>[k,(x[i]||"").trim()])))}
async function loadProducts(){const u=CONFIG.PRODUCTS_CSV_URL||"products.sample.csv";
try{return parseCSV(await (await fetch(u)).text())}catch(e){return[]}}
