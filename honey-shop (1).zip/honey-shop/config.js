// แก้ 2 ค่านี้หลังสร้าง Google Sheet / Apps Script
window.CONFIG = {
  PRODUCTS_CSV_URL: "",   // Sheet "products" > File > Share > Publish to web > CSV
  ORDERS_API_URL: "",     // Web App URL จาก apps-script.gs
  SHOP_NAME: "น้ำผึ้งบ้านสวน",
  SHOP_ADDRESS: "99 หมู่ 1 ต.ตัวอย่าง อ.เมือง จ.เชียงใหม่ 50000",
  SHOP_PHONE: "081-234-5678"
};
