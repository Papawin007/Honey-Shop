โฟลเดอร์เก็บรูปสินค้า: วางไฟล์รูป (jpg/png/svg) แล้วใส่ path ในคอลัมน์ image ของ Google Sheet เช่น images/wildflower.svg
